# HanLingo IPA sound pack

Human-recorded general IPA demonstrations: 15 vowels and 3 consonants. Consonant clips retain any supporting vowels. These are not local words, synthesized speech, lexical tones or sandhi.

Each MP3 is licensed CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/
Transcoded from the source Ogg; no trimming, pitch shifting, or phonetic synthesis.
The source file license applies to each recording. No speaker endorsement is implied.

## [i] — Close front unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close_front_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: b474c0a364f4d3f7830df7cab1887ef3b9205d6e

## [y] — Close front rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close_front_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 1be48b361894a9e7a5524c8d25102dc26468ff3e

## [u] — Close back rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close_back_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: ec885fb9088c69e0ceed6c41cec7deb86dce4275

## [ɪ] — Near-close near-front unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Near-close_near-front_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 90b0522dcb269043398b5c841cad38cc83083621

## [ʏ] — Near-close near-front rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Near-close_near-front_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 1083060fc3433784c18c3b9a8a8553ca6dd40d7a

## [ʊ] — Near-close near-back rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Near-close_near-back_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: a13e1766302a657f906d31104975c87e0b5a3587

## [e] — Close-mid front unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close-mid_front_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: a7d6ea1cac2b7886ea2b4f103cb5ba1833df940c

## [ø] — Close-mid front rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close-mid_front_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 6fc5342f0de9e3458d1ee777396c47e5f7d92cba

## [ə] — Mid-central vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Mid-central_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: b46666835bad941e68d73fbf59a6134f9bf1a244

## [ɤ] — Close-mid back unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close-mid_back_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: aba8561b2e66e357f8a7e6c323b73eed2014ce2d

## [o] — Close-mid back rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Close-mid_back_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 6e648d7e4aaa94eb9332d5b92e2e9f802213c494

## [œ] — Open-mid front rounded vowel
JøMa
https://commons.wikimedia.org/wiki/File:Open-mid_front_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 2ec2bb7ad1e0d1f7ef41cc383ae0c346f1e84de3

## [ɔ] — Open-mid back rounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Open-mid_back_rounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 65ccf8f231e7d05a8a06b7522b7b24e040d1d0dc

## [ɐ] — Near-open central unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Near-open_central_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: 22ba4684bc7974a6d8249ca64c20747c5d4b642e

## [a] — Open front unrounded vowel
Denelson83
https://commons.wikimedia.org/wiki/File:Open_front_unrounded_vowel.ogg
https://creativecommons.org/licenses/by-sa/3.0/
General phonetic demonstration.
Original SHA-1: ee33026172662d8e770c2965cc0958938cbec25e

## [p] — Voiceless bilabial plosive
Peter Isotalo
https://commons.wikimedia.org/wiki/File:Voiceless_bilabial_plosive.ogg
https://creativecommons.org/licenses/by-sa/3.0/
Full consonant demonstration, including any supporting vowels. Not an isolated local syllable or a word recording.
Original SHA-1: d130da4673b9eca7f038cdb43ea9db83145a08e9

## [m] — Bilabial nasal
Peter Isotalo
https://commons.wikimedia.org/wiki/File:Bilabial_nasal.ogg
https://creativecommons.org/licenses/by-sa/3.0/
Full consonant demonstration, including any supporting vowels. Not an isolated local syllable or a word recording.
Original SHA-1: 9aa284e454f590dd1cce25dbd4da61faef2f1af7

## [ŋ] — Velar nasal
Peter Isotalo
https://commons.wikimedia.org/wiki/File:Velar_nasal.ogg
https://creativecommons.org/licenses/by-sa/3.0/
Full consonant demonstration, including any supporting vowels. Not an isolated local syllable or a word recording.
Original SHA-1: 2a61afbbfddff3ee4c9caf9827bd0829dd7b44de
